﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Net;

namespace HamilltonLongs
{
    class Program
    {
      
        static void ConvertAndSave(string filename, List<string> names)
        {
            using (FileStream fs = File.Open(filename, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                foreach (var item in names)
                {
                    byte[] buffer = new byte[13];
                    for (int i = 0; i < item.Length; i++)
                    {
                        buffer[i] = Convert.ToByte(item[i]);
                        if (i == 11)
                            break;
                    }
                    Console.Write(item+" -> ");
                    for (int i = 0; i < 13; i++)
                    {
                        Console.Write("{0} ", buffer[i]);
                        fs.WriteByte(buffer[i]);
                    }
                    Console.WriteLine();
                }
            }
        }

        static List<String> ReadMatNameFile(string filename, string wcn, ref string lco)
        {
            bool startAdding = false;
            List<String> matnames = new List<String>();
            using (TextReader tr = File.OpenText(filename))
            {
                while (tr.Peek() >= 0)
                {
                    string s = tr.ReadLine();
                    if (s.Contains(":"))
                    {
                        startAdding = false;
                        string _wcn = s.Split(':')[0].TrimStart('[');
                        if (_wcn == (wcn))
                        {
                            startAdding = true;
                            lco = s.Split(':')[1].TrimEnd(']');
                        }
                    }

                    if (startAdding)
                    {
                        if (s.Contains("="))
                        {
                            matnames.Add(s.Split('=')[0]);
                        }
                    }
                }
                int empties = 33 - matnames.Count;
                for (int i = 0; i < empties; i++)
                {
                    matnames.Add("");
                }
            }
            return matnames;
        }
        static List<String> ReadLcoNameFile(string filename, string wcn)
        {
            bool startAdding = false;
            string[] _names = new string[99];
            for (int i = 0; i < 99; i++)
            {
                _names[i] = " ";
            }
            List<String> lconames = new List<String>();
            using (TextReader tr = File.OpenText(filename))
            {
                while (tr.Peek() >= 0)
                {
                    
             
                    string s = tr.ReadLine();
                    if (s.Contains("["))
                    {
                        startAdding = false;
                        string _wcn = s.TrimStart('[').TrimEnd(']');
                        if (_wcn == (wcn))
                        {
                            startAdding = true;
                        }
                    }

                    if (startAdding)
                    {
                        if (s.Contains("="))
                        {
                            int lconummer = Convert.ToInt16(s.Split('=')[0].Replace("Lco",""));
                            if ((lconummer > 0) && (lconummer < 49))
                                _names[lconummer - 1] = s.Split('=')[1];
                            if ((lconummer > 100) && (lconummer < 221))
                                _names[lconummer - 100 + 47] = s.Split('=')[1];
                            if ((lconummer > 220) && (lconummer < 237))
                                _names[lconummer - 220 + 63] = s.Split('=')[1];


                        }
                    }
                }
                foreach (var item in _names)
                {
                    lconames.Add(item);
                }
                
            }
            return lconames;
        }

        static void UploadToFtp(string ftpPath, string filename)
        {
            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpPath);
            request.Method = WebRequestMethods.Ftp.UploadFile;
            request.Credentials = new NetworkCredential("anonymous", "abc");
            byte[] fileContents;
            using (StreamReader sourceStream = new StreamReader(filename))
            {
                fileContents = Encoding.UTF8.GetBytes(sourceStream.ReadToEnd());
            }

            request.ContentLength = fileContents.Length;

            using (Stream requestStream = request.GetRequestStream())
            {
                requestStream.Write(fileContents, 0, fileContents.Length);
            }

            using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
            {
                Console.WriteLine($"Upload File Complete, status {response.StatusDescription}");
            }            
       }

        static string checkArgsAndReturnWcn(string[] args)
        {
             if (args.Length < 2)
            {
                Console.WriteLine("Please enter filename and hostaddress - Continue with any key");
                return "";
            }
            try
            {
                System.Net.IPAddress ip = System.Net.IPAddress.Parse(args[2]);
                return Convert.ToString(ip.GetAddressBytes()[3]);
            }
            catch (ArgumentNullException e)
            {
                Console.WriteLine("ArgumentNullException caught!!!");
                Console.WriteLine("Message : " + e.Message);
                return "";
            }

            catch (FormatException e)
            {
                Console.WriteLine("FormatException caught!!!");
                Console.WriteLine("Message : " + e.Message);
                return "";
            }

            catch (Exception e)
            {
                Console.WriteLine("Exception caught!!!");
                Console.WriteLine("Message : " + e.Message);
                return "";
            }
        }

        static void printUsage()
        {
            Console.WriteLine("Usage:");
            Console.WriteLine("  UPM filename hostname = upload material names ");
            Console.WriteLine("  UPL Filename =  upload lco names ");
            Console.WriteLine("  Continue with any key");
        }

        static void Main(string[] args)
        {
            try
            {
               File.Delete("result.txt");
               if (args[0].ToString() == "UPM")
                {
                    string wcn = checkArgsAndReturnWcn(args);
                    if (wcn != "")
                    {
                        string filename = args[1];
                        string lco = "0";
                        List<String> matnames = ReadMatNameFile(filename, wcn, ref lco);
                        filename = Path.ChangeExtension(filename, lco);
                        ConvertAndSave(filename, matnames);

                        string ftpPath = "ftp://" + args[2] + "/FlashDisk/Eladesign/" + filename;
                        UploadToFtp(ftpPath, filename);
                        using (StreamWriter tr = File.CreateText("result.txt"))
                        {
                            tr.WriteLine("UPM ok");
                        }
                    }
                }
                else
                if (args[0].ToString() == "UPL")
                    {
                        string wcn = checkArgsAndReturnWcn(args);
                        if (wcn != "")
                        {
                            string filename = args[1];

                            List<String> names = ReadLcoNameFile(filename, wcn);
                            filename = Path.ChangeExtension(filename, wcn);
                            ConvertAndSave(filename, names);

                            string ftpPath = "ftp://" + args[2] + "/FlashDisk/Eladesign/" + filename;
                            UploadToFtp(ftpPath, filename);
                            using (StreamWriter tr = File.CreateText("result.txt"))
                            {
                                tr.WriteLine("UPL ok");
                            }
                        }
                    Console.ReadKey();
                    return;
                    }
                    else
                    {
                        printUsage();
                        //                   Console.ReadKey();
                    }
            }
            catch (Exception)
            {
                printUsage();
                //Console.WriteLine("Fehler: " + exc.Message);
//                Console.ReadKey();

            }
        }
    }
}
